var searchData=
[
  ['element_5ftype',['element_type',['../classSharedPtr.html#afcc88976c36373d328d8e1e5f1882c2b',1,'SharedPtr']]],
  ['elementsvector',['ElementsVector',['../classMatrix.html#afe5c25c52be01ba404d9fec05b7f1dc1',1,'Matrix']]]
];
