var searchData=
[
  ['batterytype',['BatteryType',['../classBatteryHolder.html#a05fd25225ae1951e22d60ed931f93821',1,'BatteryHolder']]]
];
