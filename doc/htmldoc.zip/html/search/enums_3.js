var searchData=
[
  ['metric',['Metric',['../Nuts_8h.html#abf74dfd688b4203cefa6d49f8d14403e',1,'Nuts.h']]]
];
