var searchData=
[
  ['crowntype',['CrownType',['../classFutabaS3003.html#a64046cc481f09be2f80f18fdd0b40fc7',1,'FutabaS3003']]]
];
